package job;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping("requestlogin")
public class LoginAction {
	
	DbOperations db=new DbOperations();
	
	@Autowired
	ServiceRequester requestBean;

	public ServiceRequester getRequestBean() {
		return requestBean;
	}


	public void setRequestBean(ServiceRequester requestBean) {
		this.requestBean = requestBean;
	}


	@RequestMapping(method=RequestMethod.GET)
	public ModelAndView getmethod()
	{
		ServiceRequester requestbean=new ServiceRequester();
		ModelAndView mdlvie=new ModelAndView();
		mdlvie.setViewName("login");
		mdlvie.addObject("requestbean",requestbean);
		
		return mdlvie;
	}
	
	
	@RequestMapping(method=RequestMethod.POST)
	public ModelAndView userbeandemo(ServiceRequester requestbean,HttpSession session,Jobs jobbean)
	{
		
		ModelAndView mdlvie=new ModelAndView();

		if(db.checkuser(requestbean.getRq_username().toString().trim()))
		{
			System.out.println("Am Here");
				if(db.checkUserAndPassword(requestbean.getRq_username().toString().trim(),requestbean.getRq_password().toString().trim()))
				{
					System.out.println("UserName:"+requestbean.getRq_username());
					System.out.println("Password:"+requestbean.getRq_password());
					db.changestatus(requestbean.getRq_username().toString().trim(),1);
					mdlvie.addObject("jobbean",jobbean);
					mdlvie.setViewName("userwelcome");
					session.setAttribute("username",requestbean.getRq_username());
				}
				else
				{
					mdlvie.setViewName("login");
				}
		}
		else
		{
			mdlvie.setViewName("Register");
		}
		
		
		
		mdlvie.addObject("requestbean",requestbean);
		return mdlvie;
		
	}
	

}
