package job;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping("requestlogout")
public class LogoutAction
{

	DbOperations db=new DbOperations();
	@Autowired
	ServiceRequester requestbean;;

	public ServiceRequester getRequestbean() {
		return requestbean;
	}

	public void setRequestbean(ServiceRequester requestbean) {
		this.requestbean = requestbean;
	}




	@RequestMapping(method=RequestMethod.POST)
	public ModelAndView logoutAction(HttpSession session)
	{
		ServiceRequester requestbean=new ServiceRequester();
		String uname=session.getAttribute("username").toString().trim();
		System.out.println(uname);
		ModelAndView mdl=new ModelAndView();
		db.changestatus(uname, 0);
		session.invalidate();
		mdl.setViewName("login");
		mdl.addObject("requestbean",requestbean);
		return mdl;
	}
}

