package job;

import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.hibernate.Query;
import org.hibernate.Session;

public class DbOperations 
{
	
Session session;
	
	
	public boolean checkuser(String uname)
	{
		session=SessionUtility.GetSessionConnection();
				
		String hql = "FROM job.ServiceRequester where rq_username = :username";
		System.out.println(uname);
		Query query = session.createQuery(hql);
		query.setString("username",uname);
		

		
		
		@SuppressWarnings("unchecked")
		List<ServiceRequester> results = query.list();
		System.out.println(results);
		Iterator<ServiceRequester> it=results.iterator();
		
		if (it.hasNext()) {
			
			return true;
		}
		else
		{
			
		return false;
		}
	
	}
	
	
	public boolean changestatus(String uname,int status)
	{
		 session=SessionUtility.GetSessionConnection();
		
		Query query = session.createQuery("update job.ServiceRequester set rq_status = :statusval where rq_username = :unameval");
		
		query.setParameter("statusval",status);
		query.setParameter("unameval",uname);
		
		if (query.executeUpdate()==1) {
			
			SessionUtility.closeSession(null);
			return true;
		}
		else
		{
			return false;
		}
		
		
		
	}
	
	
	public boolean changepassword(String uname,String password)
	{
		 session=SessionUtility.GetSessionConnection();
		
		Query query = session.createQuery("update UserEntity set upass = :statusval where uname = :unameval");
		
		query.setParameter("statusval",password);
		query.setParameter("unameval",uname);
		
		if (query.executeUpdate()==1) {
			
			SessionUtility.closeSession(null);
			return true;
		}
		else
		{
			return false;
		}
		
		
		
	}
	
	
	
	public boolean checkUserAndPassword(String uname,String password){
		
		
		session=SessionUtility.GetSessionConnection();	
		String hql = "FROM job.ServiceRequester where rq_username = :username AND rq_password= :password";
		Query query = session.createQuery(hql);
		query.setParameter("username",uname);
		query.setParameter("password",password);
		
		
		@SuppressWarnings("unchecked")
		List<ServiceRequester> results = query.list();
		
		Iterator<ServiceRequester> it=results.iterator();	
		
		if (it.hasNext()) {
			
			return true;
		}
		else
		{
			
		return false;
		}	
	}
	
	
	public boolean checkstatus(String uname)
	{
		
		 session=SessionUtility.GetSessionConnection();
		
		String hql = "FROM ServiceRequester where rq_username = :username";
		
		Query query = session.createQuery(hql);
		
		query.setParameter("username",uname);
		
		@SuppressWarnings("unchecked")
		List<ServiceRequester> results = query.list();	
		Iterator<ServiceRequester> it=results.iterator();
		
		System.out.println(it);
		ServiceRequester rq=it.next();
		
		if (rq.getRq_status()==1) {
			
			return true;
		}
		else
		{
			
		return false;
		}
		
	}
	
	
	
	public boolean InsertDatabase(String name,String uname,String password,String email,int contact,String address)
	{
		 session=SessionUtility.GetSessionConnection(); 
		 ServiceRequester service=new ServiceRequester();
		 service.setRq_name(name);
		 service.setRq_username(uname);
		 service.setRq_password(password);
		 service.setRq_email(email);
		 service.setRq_address(address);
		 service.setRq_contact(contact);
			
			
		
			
			
			
//			Jobs j=new Jobs();
//			j.setJob_id(1);
//			j.setJob_name("java developer");
//			j.setJob_amount(5000);
//			j.setJob_experience("2 Years");
//			j.setSpobj(service);
			//Set<Jobs> set=new HashSet<Jobs>();
			//set.add(j);
			//set.add(j1);
			//service.setJobs(set);
			
			
			//session.save(j);
			//session.save(j1);
		 
		 try{
			 session.save(service);
				//session.save(j);
				//session.save(j1); 
		 SessionUtility.closeSession(null);
		 return true;
		 }
		 catch(Exception e1)
		 {
			 System.out.println("failed insert"+e1);
			 return false;
		 }
		 
		
	
	}
	
	public boolean Addjob(int id,String j_name,String j_spec,String j_exp,int j_amt)
	{
		 session=SessionUtility.GetSessionConnection(); 
		RequestJobs j=new RequestJobs();
		j.setJob_id(id);
		j.setJob_name(j_name);
		j.setJob_specialization(j_spec);
		j.setJob_experience(j_exp);
		j.setJob_amount(j_amt);
		//j.setSpobj(service);
		session.save(j);
		//session.getSession(service);
		Set<RequestJobs> set=new HashSet<RequestJobs>();
		set.add(j);
	
		//service.setJobs(set);
			
		
			
			
			
//			Jobs j=new Jobs();
//			j.setJob_id(1);
//			j.setJob_name("java developer");
//			j.setJob_amount(5000);
//			j.setJob_experience("2 Years");
//			j.setSpobj(service);
			//Set<Jobs> set=new HashSet<Jobs>();
			//set.add(j);
			//set.add(j1);
			//service.setJobs(set);
			
			
			//session.save(j);
			//session.save(j1);
		 
		 try{
			 	session.save(j);
				//session.getSession(service);
				//Set<Jobs> set=new HashSet<Jobs>();
				//set.add(j);
			 	SessionUtility.closeSession(null);
		 return true;
		 }
		 catch(Exception e1)
		 {
			 System.out.println("failed insert"+e1);
			 return false;
		 }
		 
		
	
	}


	
	
	public static void main(String[] args) 
	{
	DbOperations db=new DbOperations();
	System.out.println(db.checkUserAndPassword("job","job"));
	}
	
	
	

}


