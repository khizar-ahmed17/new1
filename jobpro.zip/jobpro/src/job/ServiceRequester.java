package job;

import java.util.Set;

import org.springframework.stereotype.Controller;


@Controller
public class ServiceRequester 
{
	private int rq_id;
	private String rq_name;
	private String rq_username;
	private String rq_password;
	private String rq_email;
	private int rq_contact;
	private String rq_address;
	public String getRq_name() {
		return rq_name;
	}

	public void setRq_name(String rq_name) {
		this.rq_name = rq_name;
	}

	private int rq_status;
	
	private Set<RequestJobs> jobs;

	public int getRq_id() {
		return rq_id;
	}

	public void setRq_id(int rq_id) {
		this.rq_id = rq_id;
	}

	public String getRq_username() {
		return rq_username;
	}

	public void setRq_username(String rq_username) {
		this.rq_username = rq_username;
	}

	public String getRq_password() {
		return rq_password;
	}

	public void setRq_password(String rq_password) {
		this.rq_password = rq_password;
	}

	public String getRq_email() {
		return rq_email;
	}

	public void setRq_email(String rq_email) {
		this.rq_email = rq_email;
	}

	public int getRq_contact() {
		return rq_contact;
	}

	public void setRq_contact(int rq_contact) {
		this.rq_contact = rq_contact;
	}

	public String getRq_address() {
		return rq_address;
	}

	public void setRq_address(String rq_address) {
		this.rq_address = rq_address;
	}

	public int getRq_status() {
		return rq_status;
	}

	public void setRq_status(int rq_status) {
		this.rq_status = rq_status;
	}

	/**
	 * @return the jobs
	 */
	public Set<RequestJobs> getJobs() {
		return jobs;
	}

	/**
	 * @param jobs the jobs to set
	 */
	public void setJobs(Set<RequestJobs> jobs) {
		this.jobs = jobs;
	}

	

}
