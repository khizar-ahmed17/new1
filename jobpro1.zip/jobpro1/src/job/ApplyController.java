package job;

import java.util.Iterator;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.classic.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping("requestapply")
public class ApplyController
{
	@Autowired
	ServiceProvider jobbean;

	public ServiceProvider getJobbean() {
		return jobbean;
	}

	public void setJobbean(ServiceProvider jobbean) {
		this.jobbean = jobbean;
	}

	@RequestMapping(method=RequestMethod.GET)
	public ModelAndView movetoposition()
	{
			System.out.println("In Get method of position");
			ModelAndView mdlv=new ModelAndView();
			ServiceProvider jobbean=new ServiceProvider();
			Session session=(Session)SessionUtility.GetSessionConnection();
			String hql = "FROM job.ServiceProvider";
			Query query = session.createQuery(hql);
			List<ServiceProvider> results = query.list();
			Iterator<ServiceProvider> it=results.iterator();
			it.next().setApply_request(1);
			mdlv.setViewName("userwelcome");
			
			SessionUtility.closeSession(null);
			return mdlv;
		
		}
	
	@RequestMapping(method=RequestMethod.POST)
	public ModelAndView nextposition(ServiceProvider jobbean)
	{
		System.out.println("In post method of Appply control");
		ModelAndView md=new ModelAndView();
		
		
	//	md.addObject("positions",results);
		md.addObject("jobbean",jobbean);
		md.setViewName("userwelcome");
		return md;
		
	}
	
	
}
