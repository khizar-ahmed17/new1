package job;

import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Transaction;
import org.hibernate.classic.Session;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.transform.Transformers;

public class Demo 
{
public static void main(String[] args) 
{
	
	
	/*
	
	
	ServiceProvider service=new ServiceProvider();
	service.setSp_username("company");
	service.setSp_password("root");
	service.setSp_email("company@gamil.com");
	service.setSp_website("company.com");
	service.setSp_status(0);
	service.setSp_address("1st Street");
	service.setApply_request(0);
	
	
	



	Jobs j=new Jobs();
	j.setJob_id(1);
	j.setJob_name("java developer");
	j.setJob_amount(5000);
	j.setJob_experience("2 Years");
	j.setJob_specialization("python");
	j.setSpobj(service);
	


	
	
	ServiceRequester service1=new ServiceRequester();
	service1.setRq_id(1);
	service1.setRq_name("name");
	service1.setRq_username("job");
	service1.setRq_password("job");
	service1.setRq_email("job@gmail.com");
	service1.setRq_address("new street");
	service1.setRq_contact(2);
	service1.setRq_status(0);
	
	RequestJobs jb=new RequestJobs();
	jb.setJob_id(1);
	jb.setJob_experience("1 Year");
	jb.setJob_name("Developer");
	jb.setJob_specialization("Java");
	jb.setJob_amount(20000);
	jb.setRqobj(service1);
	
	// e n d
	
	*/
	
	//
	
	
	
	/*
	
	ServiceProvider service1=new ServiceProvider();
	service1.setSp_username("onecompany");
	service1.setSp_password("root");
	service1.setSp_email("onecompany@gamil.com");
	service1.setSp_website("onecompany.com");
	service1.setSp_status(0);
	service1.setSp_address("First Street");
	service1.setSp_id(1);
	service1.setApply_request(0);
	
	
	
	
	Jobs j1=new Jobs();
	j1.setJob_id(2);
	j1.setJob_name("dot net developer");
	j1.setJob_amount(1000);
	j1.setJob_experience("1 Years");
	j1.setJob_specialization("dot net");
	j1.setSpobj(service1);
	
	

	
	ServiceRequester service2=new ServiceRequester();
	service2.setRq_id(2);
	service2.setRq_name("Ramu");
	service2.setRq_username("ramu");
	service2.setRq_password("root");
	service2.setRq_email("ramu@gmail.com");
	service2.setRq_address("rajiv nagar street");
	service2.setRq_contact(3);
	service2.setRq_status(0);
	
	RequestJobs jb1=new RequestJobs();
	jb1.setJob_id(2);
	jb1.setJob_experience("2 Year");
	jb1.setJob_name("Supporter");
	jb1.setJob_specialization("Java");
	jb1.setJob_amount(15000);
	jb1.setRqobj(service2);
	
	
	*/
	
	
	/*
	
	Set<Jobs> set=new HashSet<Jobs>();
	
	//set.add(j1);
	//service1.setJobs(set);
	set.add(j);
	service.setJobs(set);
	
	Set<RequestJobs> set1=new HashSet<RequestJobs>();
	
	//set1.add(jb1);
	//service2.setJobs(set1);
	set1.add(jb);
	service1.setJobs(set1);
	
	
	Session session=(Session) SessionUtility.GetSessionConnection();
	session.save(service);
	session.save(j);
	//session.save(service1);
	//session.save(j1);
	
	
	session.save(service1);
	session.save(jb);
	//session.save(service2);
	//session.save(jb1);
	
	
	
	SessionUtility.closeSession(null);									
	
	
	
	*/
	

	/*
	
//	Condition to get the name of the requester who is specialized in a particular job
	Session session1=(Session)SessionUtility.GetSessionConnection();
	
	Criteria cr=session1.createCriteria(ServiceRequester.class,"ser");
	cr.createAlias("ser.jobs", "ad");
	cr.add(Restrictions.eq("ad.job_specialization","Java"));	
	List<ServiceRequester> ad=cr.list();
	Iterator it=ad.iterator();
	System.out.println(ad);
	if(it.hasNext())
	{
		System.out.println("in loop");
		ServiceRequester s=(ServiceRequester) it.next();
		System.out.println(s.getRq_name());
	}
	System.out.println("what am i"+ad.get(0).getRq_username());
	
	
	*/
	
	
	
	/*
	
	//Condition to get the available jobs from the company
	
	Session session2=(Session)SessionUtility.GetSessionConnection();
	Query q=session2.createQuery("From job.ServiceProvider");
	
	List<ServiceProvider> results = q.list();
	
	Iterator<ServiceProvider> itr=results.iterator();
	
	Set<Jobs> se=itr.next().getJobs();
	
	Iterator<Jobs> ads=se.iterator();
	
	while (ads.hasNext()) {
		Jobs a=ads.next();
		
		System.out.println(a.getJob_name());
			
	}
									
	
	*/
	
	/*
	
	//To get A particular column - For Displaying Specialization from Request Jobs
	Session session1=(Session)SessionUtility.GetSessionConnection();
	Criteria cr = session1.createCriteria(RequestJobs.class)
		    .setProjection(Projections.projectionList()
		      .add(Projections.property("job_specialization"), "job_specialization"))
		    .setResultTransformer(Transformers.aliasToBean(RequestJobs.class));

		  List<RequestJobs> list = cr.list();
		  Iterator<RequestJobs> iter=list.iterator();
		  while(iter.hasNext())
		  {
			  System.out.println(iter.next().getJob_specialization());
		  }
		  
		  
		  
		  */
	
	
	/*
	
	//When SercviceRequester logins
	
	//To get A particular column - For Displaying Specialization from Jobs
		Session session1=(Session)SessionUtility.GetSessionConnection();
		Criteria cr = session1.createCriteria(Jobs.class)
			    .setProjection(Projections.projectionList()
			      .add(Projections.property("job_name"), "job_name"))
			    .setResultTransformer(Transformers.aliasToBean(Jobs.class));

			  List<Jobs> list = cr.list();
			  Iterator<Jobs> iter=list.iterator();
			  while(iter.hasNext())
			  {
				  System.out.println(iter.next().getJob_name());
			  }
	
	
	*/
	
	
	
	/*
//	Condition to get the name of the Company who has posted a particular job
	Session session1=(Session)SessionUtility.GetSessionConnection();
	
	Criteria cr=session1.createCriteria(ServiceProvider.class,"ser");
	cr.createAlias("ser.jobs", "ad");
	cr.add(Restrictions.eq("ad.job_name","java developer"));	
	List<ServiceProvider> ad=cr.list();
	Iterator<ServiceProvider> it=ad.iterator();
	System.out.println(ad);
	while(it.hasNext())
	{
		System.out.println("in loop");
		System.out.println(it.next().getSp_username());
		
	}
	//System.out.println("what am i"+ad.get(0).getRq_username());
	
	
	*/
		  
	//updating the value of field in a sql
	
	Session session=(Session)SessionUtility.GetSessionConnection();
	String hql = "FROM job.ServiceProvider";
	Query query = session.createQuery(hql);
	List<ServiceProvider> results = query.list();
	Iterator<ServiceProvider> it=results.iterator();
	it.next().setApply_request(0);
	
	SessionUtility.closeSession(null);
	
	
		  
	}
}
